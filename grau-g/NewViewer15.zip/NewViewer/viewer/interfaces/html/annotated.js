var annotated =
[
    [ "BasicPlugin", "class_basic_plugin.html", "class_basic_plugin" ]
];