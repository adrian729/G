var searchData=
[
  ['drawplugin',['drawPlugin',['../class_basic_plugin.html#ae634a5c4accdb7f60715ea623187afc3',1,'BasicPlugin']]],
  ['drawscene',['drawScene',['../class_basic_plugin.html#aa5077d20dbabd8d67f49bee3163d11d3',1,'BasicPlugin']]]
];
