var searchData=
[
  ['scene',['scene',['../class_basic_plugin.html#a23829e4c8cbe6b5c25f234ff35d26982',1,'BasicPlugin']]]
];
