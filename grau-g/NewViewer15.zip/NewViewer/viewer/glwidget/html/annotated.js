var annotated =
[
    [ "GLWidget", "class_g_l_widget.html", "class_g_l_widget" ]
];