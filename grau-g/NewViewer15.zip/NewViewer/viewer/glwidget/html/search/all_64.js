var searchData=
[
  ['defaultprogram',['defaultProgram',['../class_g_l_widget.html#a0bd14e0a8b8e2959464a9eb36bdd6733',1,'GLWidget']]],
  ['drawaxes',['drawAxes',['../class_g_l_widget.html#a48cce2bc8c5790a9d5255c3fb3df6816',1,'GLWidget']]],
  ['drawpoint',['drawPoint',['../class_g_l_widget.html#ac68c7866f885931eedf404a5c6cff26f',1,'GLWidget']]]
];
