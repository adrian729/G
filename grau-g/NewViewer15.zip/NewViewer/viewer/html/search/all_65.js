var searchData=
[
  ['expand',['expand',['../class_box.html#a90b977df900a2e9c2a932de4bddc9d90',1,'Box::expand(const Point &amp;p)'],['../class_box.html#a427754e15a9033c455b33ff3e4cbcee3',1,'Box::expand(const Box &amp;b)']]]
];
