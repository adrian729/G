var searchData=
[
  ['getobs',['getObs',['../class_camera.html#a8b70c9a90a86873c81d6138d0e985b2b',1,'Camera']]],
  ['glwidget',['GLWidget',['../class_g_l_widget.html',1,'GLWidget'],['../class_g_l_widget.html#a694ea02df40223ca46f3dce4f84f1412',1,'GLWidget::GLWidget()'],['../class_basic_plugin.html#aab6f9ed1f456cf5bed7165b57bedd457',1,'BasicPlugin::glwidget()']]]
];
