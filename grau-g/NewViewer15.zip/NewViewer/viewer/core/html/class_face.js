var class_face =
[
    [ "Face", "class_face.html#afdb634bc2d5287ba0d62e46b57e9dc2e", null ],
    [ "Face", "class_face.html#a92c630be63e5346db13a344013a342cb", null ],
    [ "addVertexIndex", "class_face.html#a48f81292b0a22e087d0c2d5fb7214844", null ],
    [ "computeNormal", "class_face.html#ab9671d4fc1bed3515304d982116838b7", null ],
    [ "normal", "class_face.html#ab7b1edef9bbe793956935d53efee722c", null ],
    [ "numVertices", "class_face.html#a25599a374cb677b8b10068c654083cc2", null ],
    [ "vertexIndex", "class_face.html#ab2f0de9938db29850ba1d1ca1461824b", null ]
];