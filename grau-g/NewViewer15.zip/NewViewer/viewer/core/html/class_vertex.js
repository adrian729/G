var class_vertex =
[
    [ "Vertex", "class_vertex.html#ac3516a80aadcd197740f45c70610a6eb", null ],
    [ "coord", "class_vertex.html#a11a73bc6dacc83f071a1f569d2a1fb13", null ],
    [ "setCoord", "class_vertex.html#a64647aa8fbafd66af33a5cf1064cd388", null ]
];