var searchData=
[
  ['face',['Face',['../class_face.html#afdb634bc2d5287ba0d62e46b57e9dc2e',1,'Face::Face()'],['../class_face.html#a92c630be63e5346db13a344013a342cb',1,'Face::Face(int i0, int i1, int i2, int i3=-1)']]],
  ['faces',['faces',['../class_object.html#a5765f37f243288913fa1814713a18df8',1,'Object']]]
];
