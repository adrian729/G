var searchData=
[
  ['addobject',['addObject',['../class_scene.html#a8397a3153a840a4af2943742ab00340c',1,'Scene']]],
  ['addvertexindex',['addVertexIndex',['../class_face.html#a48f81292b0a22e087d0c2d5fb7214844',1,'Face']]],
  ['applygt',['applyGT',['../class_object.html#a25268a63096acfbeceec96c688c31653',1,'Object']]]
];
