var searchData=
[
  ['radius',['radius',['../class_box.html#aad398c1f6355fd6c13d22e2139868813',1,'Box']]],
  ['readobj',['readObj',['../class_object.html#a25d76d1d24542d1b90b59c4c7a860f72',1,'Object']]]
];
