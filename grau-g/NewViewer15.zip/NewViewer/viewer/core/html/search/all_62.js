var searchData=
[
  ['boundingbox',['boundingBox',['../class_object.html#a645bfb6559e1a37ab81154b3cef4acf6',1,'Object::boundingBox()'],['../class_scene.html#aef374948496fa83dbc15404b93730951',1,'Scene::boundingBox()']]],
  ['box',['Box',['../class_box.html',1,'Box'],['../class_box.html#af41c674f885730b9468fadf73f166d63',1,'Box::Box(const Point &amp;point=Point())'],['../class_box.html#afa7a0f7e972b55968e8cab203b3ae327',1,'Box::Box(const Point &amp;minimum, const Point &amp;maximum)']]]
];
