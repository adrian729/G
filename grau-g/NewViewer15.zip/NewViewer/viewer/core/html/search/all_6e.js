var searchData=
[
  ['normal',['normal',['../class_face.html#ab7b1edef9bbe793956935d53efee722c',1,'Face']]],
  ['numvertices',['numVertices',['../class_face.html#a25599a374cb677b8b10068c654083cc2',1,'Face']]]
];
