var searchData=
[
  ['getobs',['getObs',['../class_camera.html#a8b70c9a90a86873c81d6138d0e985b2b',1,'Camera']]]
];
